# DT Node.js Challenge – Complete Submission

## Position
Node.js Intern

## Tech Stack
- Node.js
- Express.js
- JavaScript

---

## Task 1: API Creation

### POST /api/users
Creates a new user.

Request Body:
{
  "username": "rajan",
  "email": "rajan@gmail.com",
  "password": "123456"
}

---

## Task 2: API Documentation

### GET /api/users
Fetches all users.

---

## How to Run Project
1. Install Node.js
2. Open terminal in project folder
3. Run:
   npm install
   npm start
4. Server runs on port 3000

---

## Notes
This project is created for DT Node.js Intern evaluation.