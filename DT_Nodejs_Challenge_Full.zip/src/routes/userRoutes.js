const express = require("express");
const router = express.Router();

// Task 1: Create User API
router.post("/users", (req, res) => {
  const { username, email, password } = req.body;

  if (!username || !email || !password) {
    return res.status(400).json({
      success: false,
      message: "All fields are required"
    });
  }

  res.status(201).json({
    success: true,
    message: "User created successfully"
  });
});

// Task 2: Get All Users API
router.get("/users", (req, res) => {
  res.status(200).json({
    success: true,
    data: [
      {
        id: 1,
        username: "rajan",
        email: "rajan@gmail.com"
      }
    ]
  });
});

module.exports = router;