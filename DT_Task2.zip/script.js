const data = {
  "tasks": [
    {
      "task_id": 18882,
      "task_title": "Explore the world of management",
      "task_description": "As a project manager, you plan, monitor and control a project.",
      "assets": [
        {
          "asset_id": 18883,
          "asset_title": "Technical Project Management",
          "asset_description": "Story of Alignment, Scope of Agility",
          "asset_content": "https://www.youtube.com/embed/TiMrwiXJ8",
          "asset_type": "display_asset",
          "asset_content_type": "video"
        },
        {
          "asset_id": 18884,
          "asset_title": "Threadbuild",
          "asset_description": "Write down key threads",
          "asset_type": "input_asset",
          "asset_content_type": "threadbuilder"
        },
        {
          "asset_id": 18885,
          "asset_title": "Structure your pointers",
          "asset_description": "Write a 400-500 word article",
          "asset_type": "input_asset",
          "asset_content_type": "article"
        },
        {
          "asset_id": 18886,
          "asset_title": "4SA Method",
          "asset_description": "Explore more",
          "asset_content": "https://dthon.deepthought.education",
          "asset_type": "display_asset",
          "asset_content_type": "article"
        }
      ]
    }
  ]
};

document.getElementById("task-title").innerText = data.tasks[0].task_title;
document.getElementById("task-desc").innerText = data.tasks[0].task_description;

const assetsContainer = document.getElementById("assets-container");

function assetTemplate(asset) {
  return `
    <div class="asset-card">
      <h3>${asset.asset_title}</h3>
      <p>${asset.asset_description}</p>
      ${renderAssetContent(asset)}
    </div>
  `;
}

function renderAssetContent(asset) {
  if (asset.asset_content_type === "video") {
    return `<iframe src="${asset.asset_content}" allowfullscreen></iframe>`;
  }

  if (asset.asset_content_type === "article" && asset.asset_type === "display_asset") {
    return `<a href="${asset.asset_content}" target="_blank">Read Article</a>`;
  }

  if (asset.asset_type === "input_asset") {
    return `<textarea placeholder="Write your response here..."></textarea>`;
  }

  return "";
}

data.tasks[0].assets.forEach(asset => {
  assetsContainer.innerHTML += assetTemplate(asset);
});
